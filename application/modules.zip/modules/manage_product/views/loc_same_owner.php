<style>
	.price-section .label {
		font-size: 10px;
	}
</style>

 <h2>Lokasi Lain dari Pemilik lokasi ini</h2>

<div class="room-list listing-style3 hotel" id="post-data">
	
    
</div>

<a href="#" class="load-more button green full-width btn-large fourty-space" id="load_more" data-val="0">LOAD MORE LOCATION</a>