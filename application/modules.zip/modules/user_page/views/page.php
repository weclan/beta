<div class="container">
    <div id="main">
        <div class="tab-container full-width-style arrow-left dashboard">
            <ul class="tabs">
                <li class="active"><a data-toggle="tab" href="#dashboard"><i class="soap-icon-anchor circle"></i>Dashboard</a></li>
                <li class=""><a data-toggle="tab" href="#profile"><i class="soap-icon-user circle"></i>Profil</a></li>
                <li class=""><a data-toggle="tab" href="#booking"><i class="soap-icon-businessbag circle"></i>Penjualan</a></li>
                <li class=""><a data-toggle="tab" href="#wishlist"><i class="soap-icon-wishlist circle"></i>Wishlist</a></li>
                <li class=""><a data-toggle="tab" href="#travel-stories"><i class="soap-icon-conference circle"></i>Daftar Produk</a></li>
                <li class=""><a data-toggle="tab" href="#settings"><i class="soap-icon-settings circle"></i>Pengaturan</a></li>
            </ul>

            <div class="tab-content">
                <!-- content -->

                
                
            </div>
            
        </div>
    </div>
</div> 