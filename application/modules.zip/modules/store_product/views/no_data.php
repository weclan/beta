<?php
$back = base_url().'store_product';
?>
<div class="tab-pane fade in active">

	<div class="row">
		<div class="col-md-6">
	    	<h2>No Data</h2>
	    </div>

	    <div class="col-md-6">
	        <a href="<?= $back ?>" class="button btn-small yellow pull-right">BACK</a>
	    </div>
	</div>  

</div>