<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Mdl_based_duration extends CI_Model
{

function __construct() {
parent::__construct();
}

function get_table() {
    $table = "price_bd";
    return $table;
}

function get($order_by){
    $table = $this->get_table();
    $this->db->order_by($order_by);
    $query=$this->db->get($table);
    return $query;
}

function create(){
    $arr = array(
        '1_month' => '',
        '2_month' => '',
        '3_month' => '',
        '4_month' => '',
        '5_month' => '',
        '6_month' => '',
        '7_month' => '',
        '8_month' => '',
        '9_month' => '',
        '10_month' => '',
        '11_month' => '',
        '12_month' => ''
    );
    $this->db->insert("price_bd", $arr);
    return $this->db->insert_id();
}

function get_with_limit($limit, $offset, $order_by) {
    $table = $this->get_table();
    $this->db->limit($limit, $offset);
    $this->db->order_by($order_by);
    $query=$this->db->get($table);
    return $query;
}

function get_where($id){
    $table = $this->get_table();
    $this->db->where('id', $id);
    $query=$this->db->get($table);
    return $query;
}

function get_where_custom($col, $value) {
    $table = $this->get_table();
    $this->db->where($col, $value);
    $query=$this->db->get($table);
    return $query;
}

function _insert($data){
    $table = $this->get_table();
    $this->db->insert($table, $data);
}

function update_price($id, $value, $modul){
    $this->db->where(array("prod_id" => $id));
    $this->db->update("price_bd", array($modul => $value));
}

function _update($id, $data){
    $table = $this->get_table();
    $this->db->where('id', $id);
    $this->db->update($table, $data);
}

function _delete($id){
    $table = $this->get_table();
    $this->db->where('id', $id);
    $this->db->delete($table);
}

function count_where($column, $value) {
    $table = $this->get_table();
    $this->db->where($column, $value);
    $query=$this->db->get($table);
    $num_rows = $query->num_rows();
    return $num_rows;
}

function count_all() {
    $table = $this->get_table();
    $query=$this->db->get($table);
    $num_rows = $query->num_rows();
    return $num_rows;
}

function get_max() {
    $table = $this->get_table();
    $this->db->select_max('id');
    $query = $this->db->get($table);
    $row=$query->row();
    $id=$row->id;
    return $id;
}

function _custom_query($mysql_query) {
    $query = $this->db->query($mysql_query);
    return $query;
}

}